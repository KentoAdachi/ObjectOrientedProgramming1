package problem2_err;
public class Rectangle{
	int width;
	int height;
	void setSize(int w, int h){
		this.width = w;
		this.height = h;
	}
	int getArea(){
		return this.width * thid.height;
	}
	public static void main(String[] args){
		//Rectangle r = new Rectangle();
		int a;
		r.setSize(3,4);
		System.out.println("�� = " + r.width);
		System.out.println("���� = " + r.height);	
		a = r.getArea();
		System.out.println("���̒����`�̖ʐς� " + a +"�ł��B");

	}
}

