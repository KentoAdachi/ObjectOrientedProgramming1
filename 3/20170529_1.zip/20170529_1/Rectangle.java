class Rectangle{
	int width;
	int height;

	Rectangle(int w, int h){
		this.width = 10;
		this.height = 20;
	}

	Recatngle(int w, int h){
		this.width = w;
		this.height = h;
	}

	int getArea(){
		return this.width * this.height;
	}

	void setSize(int w, int h){
		this.width = w;
		this.height = h;
	}

	boolean hasSameArea (Rectangle r1,Rectangle r2){
		return (r1.getArea() == r2.getArea());
	}


	public String toString(){
		return ("�����`�́A�� = " +  thid.width + "�A"
			+ "���� = " + this.height + "�A"
			+ "�ʐ� = " + this.getArea() + "�ł��B");
	}

}




